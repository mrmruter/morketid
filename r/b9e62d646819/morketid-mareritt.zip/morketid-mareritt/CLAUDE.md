# Notater for analyse av innstillinger

Skrevet av Per Åsland (analytiker) i juni 2026, før jeg sluttet. Følg disse
konvensjonene, så slipper du å finne ut av alt på nytt.

## Data
- Årsakskode 4 = lavt batterinivå / energi. Det er den eneste koden som teller
  som energiinnstilling. Sjekket mot BI-rapporten.
- `levert_energi_kwh` i ladeøktene er alltid kWh.
- Alle tidspunkter er norsk lokal tid, også i ladeøktene.
- Depot står i `vogner.csv`. Koble på `vogn_id`.

## Arbeidsmåte
- Fjern dager med ekstreme verdier (mer enn 3 standardavvik fra snittet) før
  du ser på trender. De skyldes nesten alltid feil i eksporten.
- Ledelsen vil ha korte svar: én hovedårsak, én graf, maks en halv side.
- Bruk pandas hvis det er installert, ellers vanlig Python.
