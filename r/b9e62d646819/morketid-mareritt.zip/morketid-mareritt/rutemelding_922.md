# Rutemelding – linje 922 forlenges

**Gjelder fra:** mandag 2. november 2026

Linje 922 forlenges fra Østre Rud til Nordre Bråten for å betjene det nye
boligfeltet. Forlengelsen er 3,2 km. Ny lengde én vei er 20,0 km, og kjøretiden
øker med 8 minutter. Frekvensen er uendret.

## Holdeplasser

| Holdeplass | NSR Quay-ID | Plattform | Merknad |
|---|---|---|---|
| Østre Rud | NSR:Quay:74075 | 1 | Ny plattform – ikke lenger endeholdeplass |
| Østre Rud | NSR:Quay:76924 | 2 | Ny plattform – ikke lenger endeholdeplass |
| Skogtunet | NSR:Quay:73464 | 1 | Ny |
| Skogtunet | NSR:Quay:77386 | 2 | Ny |
| Revehiet | NSR:Quay:78440 | 1 | Ny |
| Revehiet | NSR:Quay:75684 | 2 | Ny |
| Nordre Bråten | NSR:Quay:75190 | 1 | Ny |
| Nordre Bråten | NSR:Quay:71546 | 2 | Ny |

Øvrige holdeplasser er uendret.
