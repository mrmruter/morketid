# Datakatalog – telemetri og billettering (tillegg)

Sist oppdatert: 23. november 2026 · Eier: Seksjon for billettering og kjøretøydata

## telemetri.csv.gz

Målinger fra vognenes telematikkenhet hvert 10. minutt mens vogna er i drift.
Fila er stor (rundt en kvart million rader). Komprimert med gzip.

| Kolonne | Beskrivelse |
|---|---|
| tidspunkt_utc | Tidspunkt for målingen (UTC) |
| vogn_id | Vogn |
| soc_prosent | Batterinivå (state of charge), 0–100 % |
| utetemperatur_c | Utetemperatur målt på vogna (°C) |
| kilometerstand_km | Kilometerstand |

Ved manglende signal fra enheten skal målingen mangle.

## valideringer.csv

Billettvalideringer på linje 922, uttrekk 26.10.–22.11.2026. Kortleserne ved dørene ble fjernet
i vår. Reisekortet leses nå av billettmaskinen hos sjåføren, så alle som har reisekort, går på foran.

| Kolonne | Beskrivelse |
|---|---|
| tidspunkt | Tidspunkt for validering (lokal tid) |
| linje | Linje billettmaskinen er logget på |
| tur_id | Tur (tom hvis billettmaskinen ikke var logget på en tur) |
| stopp_id | Holdeplass der reisen startet (NSR Quay-ID) |
| sone | Takstsone |
| kortnummer | Reisekortnummer, som på baksiden av kortet |
| billettype | Passasjerkategori på billetten (voksen, barn, ungdom, student, honnør) |
| vogn_id | Vogna billettmaskinen sitter i |

## stoppesteder.csv

Uttrekk fra holdeplassregisteret (NSR) 15.09.2026 for linje 922, pluss depotet.

| Kolonne | Beskrivelse |
|---|---|
| stopp_id | NSR Quay-ID (én per plattform). Depotet har en intern ID. |
| navn | Holdeplassnavn |
| plattform | 1 = retning A (fra depotenden), 2 = retning B. Østre Rud (endeholdeplass i ytterenden) har én plattform. Haugåsen senter er knutepunkt med flere plattformer. |
| type | holdeplass / depot |
| kommune | Kommune |
| breddegrad, lengdegrad | Posisjon (WGS84) |
