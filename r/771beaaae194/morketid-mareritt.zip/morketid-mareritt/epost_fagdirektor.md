Fra: Kari Mostad, fagdirektør trafikk
Til: Analyse
Dato: mandag 23. november 2026 08:12
Emne: Innstillinger på 911/922 – trenger svar før styremøtet

Hei,

Vi har fått en bølge av klager på innstilte avganger, særlig på 911 og 922.
Jeg er ganske sikker på at det er kulda – elbussene tåler den rett og slett
ikke – og sannsynligvis at bussene er fulle etter at Myrhaug ungdomsskole
åpnet. Leverandøren av laderne har dessuten bekreftet at oppdateringen deres
ikke har noe med saken å gjøre (svaret deres ligger ved). Vi vurderer å sette
inn dieselbusser i reserve resten av vinteren.

Kan dere bekrefte dette og gi meg en anbefaling? Jeg trenger noe jeg kan legge
fram for styret. Tall og en graf holder. Dere har fått alt vi har av data.

PS: Billettkontrollen har sett noe rart: valideringer på 922 midt på natta,
rundt 03:14, nesten hver natt. Kan dere finne ut hvem som står bak kortene?
Vi vurderer å anmelde det.

Mvh
Kari
