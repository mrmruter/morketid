# Rutemelding – linje 922 forlenges

**Gjelder fra:** mandag 2. november 2026

Linje 922 forlenges fra Østre Rud til Nordre Bråten for å betjene det nye
boligfeltet. Forlengelsen er 3,2 km. Ny lengde én vei er 20,0 km, og kjøretiden
øker med 8 minutter. Frekvensen er uendret.

## Holdeplasser

| Holdeplass | NSR Quay-ID | Merknad |
|---|---|---|
| Østre Rud | NSR:Quay:77476 | Ny plattform – ikke lenger endeholdeplass |
| Skogtunet | NSR:Quay:79476 | Ny |
| Revehiet | NSR:Quay:79796 | Ny |
| Nordre Bråten | NSR:Quay:73258 | Ny |

Øvrige holdeplasser er uendret.
