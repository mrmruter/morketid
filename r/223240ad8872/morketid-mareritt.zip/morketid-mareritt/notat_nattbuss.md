# Notat: Prøveordning med nattbuss N22

**Dato:** 20. oktober 2026
**Til:** Trafikk, Billettering, Kundesenter

Fra natt til lørdag 7. november (dvs. fredag kveld 6. november) kjøres nattbuss N22 på
prøve i natt til lørdag og natt til søndag. N22 følger traseen til linje 922
i retning sentrum, med fem avganger mellom kl. 01:10 og 04:10.

N22 kjøres med vogner fra Haugåsen. Inntil ny linjekonfigurasjon er på plass
(planlagt januar) registreres valideringer på N22 som linje 922, uten tur-ID.

Ordningen evalueres etter tre måneder.
