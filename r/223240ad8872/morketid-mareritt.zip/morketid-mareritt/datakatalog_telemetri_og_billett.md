# Datakatalog – telemetri og billettering (tillegg)

## telemetri.csv.gz

Målinger fra vognenes telematikkenhet hvert 10. minutt mens vogna er i drift.
Fila er stor (flere hundre tusen rader). Komprimert med gzip.

| Kolonne | Beskrivelse |
|---|---|
| tidspunkt_utc | Tidspunkt for målingen (UTC) |
| vogn_id | Vogn |
| soc_prosent | Batterinivå (state of charge), 0–100 % |
| utetemperatur_c | Utetemperatur målt på vogna (°C) |
| kilometerstand_km | Kilometerstand |

Ved manglende signal fra enheten skal målingen mangle.

## valideringer.csv

Billettvalideringer på linje 922, uttrekk 26.10.–22.11.2026.

| Kolonne | Beskrivelse |
|---|---|
| tidspunkt | Tidspunkt for validering (lokal tid) |
| linje | Linje validatoren er konfigurert for |
| tur_id | Tur (tom hvis validatoren ikke var koblet til en tur) |
| stopp_id | Holdeplass der reisen startet (NSR Quay-ID) |
| sone | Takstsone |
| kortnummer | Reisekortnummer, som på baksiden av kortet |
| billettype | Billettype |

## stoppesteder.csv

Uttrekk fra holdeplassregisteret (NSR) 15.09.2026, linje 922 og depotholdeplass.
