# Datakatalog – trafikk og lading

Sist oppdatert: 14. august 2026 · Eier: Seksjon for trafikkdata

Alle tidspunkter er lokal tid (Europe/Oslo) med mindre annet er oppgitt.

## Linjer og depoter

| Linje | Depot | Lengde (én vei) | Kjøretid |
|---|---|---|---|
| 911 | Haugåsen | 14,2 km | 38 min |
| 922 | Haugåsen | 16,8 km | 44 min |
| 933 | Bråtejordet | 15,1 km | 40 min |
| 944 | Bråtejordet | 13,6 km | 36 min |

## avganger_per_dag.csv (BI-rapport)

Daglig rapport per linje fra BI-løsningen.

| Kolonne | Beskrivelse |
|---|---|
| dato | Trafikkdato |
| linje | Linjenummer |
| depot | Depotet linja kjøres fra |
| planlagte_avganger | Antall planlagte avganger (begge retninger) |
| innstilte_avganger_energi | Avganger innstilt helt eller delvis på grunn av lavt batteri/energi |
| snittemp_c | Døgnmiddeltemperatur ved depotet (°C) |

## turer.csv (turdata, rådata)

Én rad per planlagt tur (avgang).

| Kolonne | Beskrivelse |
|---|---|
| post_id | Teknisk løpenummer i datavarehuset |
| tur_id | Unik ID for turen (linje-dato-retning+avgangstid) |
| dato | Trafikkdato |
| linje | Linjenummer |
| retning | A = fra depotenden, B = mot depotenden |
| planlagt_avgang | Planlagt avgangstid fra første holdeplass |
| vognlop | Vognløp: én vogns planlagte turer gjennom dagen (linje + løpenummer) |
| vogn_id | Vogn som var satt opp på turen |
| status | gjennomført / innstilt / delvis innstilt |
| arsakskode | Årsakskode ved innstilling, se under |
| km_planlagt | Planlagt lengde (km) |
| km_kjort | Faktisk kjørt lengde (km) |
| passasjerer | Antall påstigende (fra billettering/APC) |

**Status:** *innstilt* betyr at turen ikke ble kjørt. *Delvis innstilt* betyr at turen
ble avbrutt underveis og at vogna kjørte til depot.

**Årsakskoder:**

| Kode | Betydning |
|---|---|
| 1 | Trafikk / vegarbeid |
| 3 | Hendelse (ulykke, sykdom om bord o.l.) |
| 4 | Lavt batterinivå / energi |
| 5 | Vær og føre |
| 7 | Annen teknisk feil |

## vogner.csv

| Kolonne | Beskrivelse |
|---|---|
| vogn_id | Vogn-ID (depotkode + nummer) |
| modell | Bussmodell |
| batterikapasitet_kwh | Nominell batterikapasitet |
| depot | Hjemmedepot |
| arsmodell | Årsmodell |
| hovedlinje | Linja vogna normalt kjører |

## ladeokter.csv

Én rad per ladeøkt, eksportert fra ladesystemet.

| Kolonne | Beskrivelse |
|---|---|
| okt_id | ID for ladeøkta |
| depot | Depot |
| lader_id | Lader (L01–L10 ved hvert depot; HURTIG = hurtiglader når alle er opptatt) |
| vogn_id | Vogn |
| type | natt / mellomlading |
| start, slutt | Start og slutt på økta |
| levert_energi_kwh | Energi levert til vogna |
